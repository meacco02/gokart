/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esergokart;

/**
 *
 * @author meaccifederico
 */
public class main 
{
    
    public static void main(String[]args)
    {
    
     Semaforo pieno=new Semaforo(2);
     Semaforo vuoto=new Semaforo(4);
     Spogliatoio S=new Spogliatoio(pieno);
     Pista P=new Pista(vuoto);
     
     Pilota P1=new Pilota(pieno,vuoto,S,P);
     Pilota P2=new Pilota(pieno,vuoto,S,P);
     Pilota P3=new Pilota(pieno,vuoto,S,P);
     Pilota P4=new Pilota(pieno,vuoto,S,P);
     Pilota P5=new Pilota(pieno,vuoto,S,P);
     Pilota P6=new Pilota(pieno,vuoto,S,P);
     Pilota P7=new Pilota(pieno,vuoto,S,P);
     Pilota P8=new Pilota(pieno,vuoto,S,P);
    
    
        P1.start();
        P2.start();
        P3.start();
        P4.start();
        P5.start();
        P6.start();
        P7.start();
        P8.start();
    
    
        
        
    }
}

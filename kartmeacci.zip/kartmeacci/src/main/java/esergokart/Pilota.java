/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esergokart;

/**
 *
 * @author meaccifederico
 */
public class Pilota extends Thread 
{
    
    Semaforo pieno;
    Semaforo vuoto;
    
    Spogliatoio S;
    Pista P;

    public Pilota(Semaforo pieno, Semaforo vuoto, Spogliatoio S, Pista P) 
    {
        this.pieno = pieno;
        this.vuoto = vuoto;
        this.S = S;
        this.P = P;
    }
    
    public void run()
    {
        
        
        S.CambioI();
        
        P.EntraPista();
        
        S.CambioI2();
    
    }
    
    
}
